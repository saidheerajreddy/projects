<?php
include 'config.php'; // Include your database configuration file

if(!isset($_SESSION['TransactionID'])){
    return;
}

// Sanitize and validate data
$customerID = $_SESSION['CustomerID'];
$transactionID = $_SESSION['TransactionID'];

// Retrieve information about items in the cart
// $sqlSelectCartItems = "SELECT carts.CartID, Inventory.ItemNumber, Inventory.Category, Inventory.Subcategory, Inventory.Name, Inventory.UnitPrice, Carts.Quantity, Transactions.TransactionID, Transactions.TransactionStatus, Transactions.TransactionDate, Transactions.TotalPrice
// FROM Carts C
// JOIN Inventory I ON Carts.ItemNumber = Inventory.ItemNumber
// JOIN Transactions T ON Carts.TransactionID = Transactions.TransactionID
// WHERE Carts.CustomerID = $customerID AND Carts.TransactionID = $transactionID AND Carts.CartStatus = 'In Cart'";

$sqlSelectCartItems = "SELECT Carts.CartID, Inventory.ItemNumber, Inventory.Category, Inventory.Subcategory, Inventory.Name, Inventory.UnitPrice, Carts.Quantity, Transactions.TransactionID, Transactions.TransactionStatus, Transactions.TransactionDate, Transactions.TotalPrice
FROM Carts
JOIN Inventory ON Carts.ItemNumber = Inventory.ItemNumber
JOIN Transactions ON Carts.TransactionID = Transactions.TransactionID
WHERE Carts.CustomerID = $customerID AND Carts.TransactionID = $transactionID AND Carts.CartStatus = 'In Cart'";


$resultSelectCartItems = $conn->query($sqlSelectCartItems);

if ($resultSelectCartItems->num_rows > 0) {
    // Display header information
    echo "<table border='1'>
        <tr>
            <th>Cart ID</th>
            <th>Item ID</th>
            <th>Category</th>
            <th>Subcategory</th>
            <th>Name</th>
            <th>Unit Price</th>
            <th>Quantity</th>
            <th>Transaction ID</th>
            <th>Transaction Status</th>
            <th>Transaction Date</th>
            <th>Total Price</th>
        </tr>";

    // Loop through the results and display information for each item in the cart
    while ($row = $resultSelectCartItems->fetch_assoc()) {
        echo "<tr>
            <td>{$row['CartID']}</td>
            <td>{$row['ItemNumber']}</td>
            <td>{$row['Category']}</td>
            <td>{$row['Subcategory']}</td>
            <td>{$row['Name']}</td>
            <td>{$row['UnitPrice']}</td>
            <td>{$row['Quantity']}</td>
            <td>{$row['TransactionID']}</td>
            <td>{$row['TransactionStatus']}</td>
            <td>{$row['TransactionDate']}</td>
            <td>{$row['TotalPrice']}</td>
        </tr>";
    }

    echo "</table>";
} else {
    echo "No items found in the cart.";
}

// Close the database connection
$conn->close();
?>
