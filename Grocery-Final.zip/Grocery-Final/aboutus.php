
<?php
include 'config.php';
session_start();
if (isset($_SESSION['username'])) {
    echo "Hello, ", $_SESSION['username'];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <script src="scripts/contactus.js"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Grocery: About Us</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .top {
            background-color: #007bff;
            padding: 10px;
            color: white;
            text-align: center;
        }

        .top img {
            max-width: 100px;
            max-height: 100px;
            margin-right: 10px;
        }

        .navbar {
            background-color: #ffffff;
            border-bottom: 1px solid #dee2e6;
        }

        .navbar-brand {
            color: #007bff;
            font-size: 24px;
            font-weight: bold;
        }

        .navbar-nav .nav-link {
            color: #495057;
        }

        .row {
            margin: 20px 0;
        }

        .column {
            background-color: #ddd;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .column2 {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        footer {
            background-color: #343a40;
            color: #ffffff;
            padding: 10px 0;
            text-align: center;
            position: relative;
            bottom: 0;
            width: 100%;
        }

        .rowCard {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
        }

        .columnCard {
            width: 50%;
            padding: 1rem;
            margin-bottom: 20px;
        }

        .card {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: 0.3s;
            border-radius: 8px;
        }

        .container {
        }

        input[type="number"] {
            width: 50px;
            text-align: center;
            margin-right: 5px;
        }

        .center {
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="top">
        <img src="images/groceries.jpeg">
        <h1>Grocery</h1>
    </div>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Grocery</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="freshproducts.php">Fresh Products</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="frozen.php">Frozen</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="pantry.php">Pantry</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="breakfastcereal.php">Breakfast & Cereal</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="baking.php">Baking</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="snacks.php">Snacks</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="candy.php">Candy</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="specialtyshops.php">Specialty Shops</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="deals.php">Deals</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="aboutus.php">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contactus.php">Contact Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="myaccount.php">My Account</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="cart.php">Shopping Cart</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="column2">
                    <div>
                <h3 class="text-center">About Us</h3>

                <div class="rowCard">
                    <div class="columnCard">
                        <div class="card">
                            <div class="container">
                                <h4><b>Austin, TX</b></h4> 
                                <p><strong>3853 Alpha Street, Austin, TX 73301</strong></p> 
                                <h5>Hours: 8 am - 9 pm</h5>
                            </div>
                        </div>
                    </div>
                    <div class="columnCard">
                        <div class="card">
                            <div class="container">
                                <h4><b>Celina, TX</b></h4> 
                                <p><strong>6493 Star Lane, Celina, TX 75009</strong></p> 
                                <h5>Hours: 8 am - 9 pm</h5>
                            </div>
                        </div>
                    </div>
                    <div class="columnCard">
                        <div class="card">
                            <div class="container">
                              <h4><b>Dallas, TX</b></h4> 
                              <p><strong>5454 Belt Line Rd, Dallas, TX 75001</strong></p>
                              <h5>Hours: 8 am - 9 pm</h5>
                            </div>
                        </div>
                    </div>
                    <div class="columnCard">
                        <div class="card">
                            <div class="container">
                                <h4><b>Houston, TX</b></h4> 
                                <p><strong>989 Knox Street, Houston, TX 77001</strong></p> 
                                <h5>Hours: 8 am - 9 pm</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

                </div>
            </div>
        </div>
    </div>

        <?php include 'footer.php'; ?>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>

</html>
