<footer class="footer">

   <script src="scripts/contactus.js"></script>

   <p class="credit"> &copy; copyright @by <span>Sai Dheeraj Reddy </span> <span id="date"><script>formatDate();</script></span> | all rights reserved! </p>

</footer>