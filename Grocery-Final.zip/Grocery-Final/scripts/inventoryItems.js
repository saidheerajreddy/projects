// Function to load data from XML file
function loadXMLData(xmlFilePath) {
    return fetch(xmlFilePath)
        .then(response => response.text())
        .then(xmlString => {
            const parser = new DOMParser();
            const xmlDoc = parser.parseFromString(xmlString, 'text/xml');
            const products = xmlDoc.querySelectorAll('product');

            const inventoryList = Array.from(products).map(product => {
                return {
                    name: product.querySelector('name').textContent.toLowerCase(),
                    quantity: parseInt(product.querySelector('quantity').textContent),
                    price: parseFloat(product.querySelector('price').textContent),
                };
            });

            return inventoryList;
        })
        .catch(error => {
          //  console.error(`Error loading XML data from ${xmlFilePath}:`, error);
            return [];
        });
}

// Function to load data from JSON file
function loadJSONData(jsonFilePath) {
    return fetch(jsonFilePath)
        .then(response => response.json())
        .then(jsonData => {
            const inventoryList = jsonData.map(item => {
                return {
                    name: (item.name || '').toLowerCase(), 
                    quantity: item.quantity || 0,
                    price: item.price || 0,
                };
            });

            return inventoryList;
        })
        .catch(error => {
            console.error(`Error loading JSON data from ${jsonFilePath}:`, error);
            return [];
        });
}

// List of XML and JSON file paths
const xmlFiles = ['xml/candy.xml', 'xml/freshproduce.xml', 'xml/frozen.xml','xml/snacks.xml'];
const jsonFiles = ['json/baking.json', 'json/breakfast.json', 'json/pantry.json'];

// Load data from multiple XML and JSON files
const xmlPromises = xmlFiles.map(xmlFile => loadXMLData(xmlFile));
const jsonPromises = jsonFiles.map(jsonFile => loadJSONData(jsonFile));

Promise.all([...xmlPromises, ...jsonPromises])
    .then(dataArrays => {
        // Combine data from all sources into a single array
        const combinedData = dataArrays.flat();

        // Set the combined data as inventoryList
        sessionStorage.setItem('inventoryList', JSON.stringify(combinedData));

        console.log('Inventory List created:', combinedData);
    })
    .catch(error => console.error('Error:', error));


function updateItemPrice(itemName) {
    const quantityInput = document.getElementById(`${itemName.toLowerCase()}-quantity`);
    const priceElement = document.getElementById(`${itemName.toLowerCase()}-price`);
    const inventory = JSON.parse(sessionStorage.getItem('inventoryList'));
    
    for (let i = 0; i < inventory.length; i++) {
        if (inventory[i].name.toLowerCase() === itemName.toLowerCase()) {
            const quantity = parseInt(quantityInput.value);
            const total = (inventory[i].price * quantity).toFixed(2);
         //   priceElement.textContent = `$${total}`;
            break;
        }
    }
}

function addToCart(itemName, itemQuantityInventory) {
    const outOfStockMessage = document.getElementById(`${itemName.toLowerCase()}-out-of-stock`);
    const quantityInput = document.getElementById(`${itemName.toLowerCase()}-quantity`);
    const added = document.getElementById('added');
    
    const inventory = JSON.parse(sessionStorage.getItem('inventoryList'));
    const cart = JSON.parse(sessionStorage.getItem('cartData')) || [];

    // Find the product in the inventory
    const product = inventory.find(product => product.name.toLowerCase() === itemName.toLowerCase());

    if (!product) {
        // Product not found in the inventory
        return;
    }

    const availableQuantity = itemQuantityInventory;
    const quantity = parseInt(quantityInput.value);

    if (quantity <= availableQuantity) {
        // Update the item price based on the selected quantity
        updateItemPrice(itemName);

        // Reduce available quantity by the selected quantity
        product.quantity -= quantity;
        sessionStorage.setItem('inventoryList', JSON.stringify(inventory));

        // Update cart
        const cartItem = {
            name: itemName,
            quantity: quantity,
            price: product.price
        };
        cart.push(cartItem);
        sessionStorage.setItem('cartData', JSON.stringify(cart));

        /*
        // Send an AJAX request to update the server-side cart
        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'updateCart.php', true);
        xhr.setRequestHeader('Content-Type', 'application/json');

        const requestData = {
            itemName: itemName,
            quantity: quantity
        };

        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    // Successful response from the server
                    console.log(xhr.responseText);
                } else {
                    // Handle errors
                    console.error('Error updating cart:', xhr.responseText);
                }
            }
        };

        xhr.send(JSON.stringify(requestData));
*/
        quantityInput.value = 1;

        // outOfStockMessage.style.display = 'none';
        // added.textContent = `${quantity} ${itemName} added!`;
        // added.style.display = 'block';
        var createNew = true;

        alert(quantity + " " + itemName + " added to cart.");
        console.log(cart.length);
        if (cart.length == 1) {
            console.log("Creating new TransactionID");
            updateDatabase(itemName, quantity, product.price, createNew);
        } else {
            createNew = false;
            console.log("Adding to existing TransactionID")
            updateDatabase(itemName, quantity, product.price, createNew);
        }

        updateCartDatabase(itemName, quantity, product.price);

    
    } else {
        // Display out of stock message
        // added.style.display = 'none';
        // outOfStockMessage.textContent = `Only ${availableQuantity} available`;
        // outOfStockMessage.style.display = 'block';
     
        alert(itemName + " out of stock. Limited to " + availableQuantity + ".");
    }
}

function updateDatabase(itemName, quantity, price, createNew) {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'updateTransaction.php', true);
    xhr.setRequestHeader('Content-Type', 'application/json');

    const requestData = {
        itemName: itemName,
        quantity: quantity,
        price: price,
        createNew: createNew,
    };

    xhr.onreadystatechange = function () {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Successful response from the server
                console.log(xhr.responseText);
            } else {
                // Handle errors
                console.error('Error updating cart:', xhr.responseText);
            }
        }
    };

    xhr.send(JSON.stringify(requestData));
}

function updateCartDatabase(itemName, quantity, price) {
    console.log("updateCartDB");
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'updateCartDB.php', true);
    xhr.setRequestHeader('Content-Type', 'application/json');

    const requestData = {
        itemName: itemName,
        quantity: quantity,
        price: price,
    };

    xhr.onreadystatechange = function () {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Successful response from the server
                console.log(xhr.responseText);
            } else {
                // Handle errors
                console.error('Error updating cart:', xhr.responseText);
            }
        }
    };

    xhr.send(JSON.stringify(requestData));
}








