<!DOCTYPE html>
<html>

<head>
    <script src="scripts/contactus.js"></script>
    <title>Grocery: Register</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">



    <style type="text/css">
         body {
            background-color: #f8f9fa;
        }

        .top {
            background-color: #007bff;
            padding: 10px;
            color: white;
            text-align: center;
        }

        .top img {
            max-width: 100px;
            max-height: 100px;
            margin-right: 10px;
        }

        .navbar {
            background-color: #ffffff;
            border-bottom: 1px solid #dee2e6;
        }

        .navbar-brand {
            color: #007bff;
            font-size: 24px;
            font-weight: bold;
        }

        .navbar-nav .nav-link {
            color: #495057;
        }

        .row {
            margin: 20px 0;
        }

        .column {
            background-color: #ddd;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .column2 {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        footer {
            background-color: #343a40;
            color: #ffffff;
            padding: 10px 0;
            text-align: center;
            position: relative;
            bottom: 0;
            width: 100%;
            margin-top:;
        }

        .rowCard {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
        }

        .columnCard {
            width: 50%;
            padding: 1rem;
            margin-bottom: 20px;
        }

        .card {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: 0.3s;
            border-radius: 8px;
        }

        .container {
        }

        input[type="number"] {
            width: 50px;
            text-align: center;
            margin-right: 5px;
        }

        .center {
            text-align: center;
        }
    </style>
</head>

<body>

     <div class="top">
        <img src="images/groceries.jpeg">
        <h1>Grocery</h1>
    </div>


    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Grocery</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="freshproducts.php">Fresh Products</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="frozen.php">Frozen</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="pantry.php">Pantry</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="breakfastcereal.php">Breakfast & Cereal</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="baking.php">Baking</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="snacks.php">Snacks</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="candy.php">Candy</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="specialtyshops.php">Specialty Shops</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="deals.php">Deals</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="aboutus.php">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contactus.php">Contact Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="myaccount.php">My Account</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="cart.php">Shopping Cart</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8" style="background-color: aliceblue; margin-top: 20px;">
                <div>
                    <h3 class="text-center">Create Account</h3>

                    <!-- Bootstrap alert for success message -->
                    <div id="successMessage" class="alert alert-success mt-3" role="alert" style="display: none;">
                        Registered successfully! <a href="myaccount.php">Click to Login Now!</a>
                    </div>

                    <form name="commentForm" class="login needs-validation" action="" method="post" onsubmit="return validateForm(event)">
                        <!-- Form inputs with Bootstrap styling -->
                        <div class="form-group">
                            <label for="username">Username:</label>
                            <input type="text" class="form-control" name="username" id="username" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Password:</label>
                            <input type="password" class="form-control" name="password" id="password" required>
                        </div>
                        <div class="form-group">
                            <label for="password2">Re-enter Password:</label>
                            <input type="password" class="form-control" name="password2" id="password2" required>
                        </div>
                        <div class="form-group">
                            <label for="first">First Name:</label>
                            <input type="text" class="form-control" name="first" id="first" required>
                        </div>
                        <div class="form-group">
                            <label for="last">Last Name:</label>
                            <input type="text" class="form-control" name="last" id="last" required>
                        </div>
                        <div class="form-group">
                            <label for="birthday">Date of Birth:</label>
                            <input type="date" class="form-control" name="birthday" id="birthday" required>
                        </div>
                        <div class="form-group">
                            <label for="age">Age:</label>
                            <input type="number" class="form-control w-25" name="age" id="age" required>
                        </div>
                        <div class="form-group">
                            <label for="number">Phone Number:</label>
                            <input type="tel" class="form-control" name="number" id="number" placeholder="(012) 345-6789" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email Address:</label>
                            <input type="email" class="form-control" name="email" id="email" required>
                        </div>
                        <div class="form-group">
                            <label for="address">Address:</label>
                            <input type="text" class="form-control" name="address" id="address" required>
                        </div>
                        <div class="form-group">
                            <label for="zipcode">Zipcode:</label>
                            <input type="text" class="form-control" name="zipcode" id="zipcode" required>
                        </div>

                        <!-- Bootstrap invalid feedback container -->
                        <div class="invalid-feedback">
                            <h6 id="8Message" style="display:none;"></h6>
                            <h6 id="pwdMessage" style="display:none;"></h6>
                            <h6 id="firstMessage" style="display:none;"></h6>
                            <h6 id="lastMessage" style="display:none;"></h6>
                            <h6 id="diffMessage" style="display:none;"></h6>
                            <h6 id="bdayMessage" style="display:none;"></h6>
                            <h6 id="phoneMessage" style="display:none;"></h6>
                            <h6 id="emailMessage" style="display:none;"></h6>
                            <h6 id="genderMessage" style="display:none;"></h6>
                            <h6 id="addMessage" style="display:none;"></h6>
                        </div>

                        <!-- Bootstrap submit button -->
                        <button type="submit" class="btn btn-primary btn-block mt-3">Submit</button>
                    </form>

                    <?php
                    include 'config.php';

                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                            $username = $_POST['username'];
                            $password = $_POST['password'];
                            $firstName = $_POST['first'];
                            $lastName = $_POST['last'];
                            $age = $_POST['age'];
                            $phoneNumber = $_POST['number'];
                            $email = $_POST['email'];
                            $address = $_POST['address'];
                            $zipcode = $_POST['zipcode'];

                            $sql2 = "INSERT INTO Customers (FirstName, LastName, Age, PhoneNumber, Email, Address, ZipCode)
                                    VALUES ('$firstName', '$lastName', '$age', '$phoneNumber', '$email', '$address', '$zipcode')";

                            if ($conn->query($sql2) === TRUE) {
                                $customerID = $conn->insert_id;

                                $sql = "INSERT INTO Users (CustomerID, UserName, Password)
                                        VALUES ('$customerID', '$username', '$password')";

                                if ($conn->query($sql) === TRUE) {
                                    echo '<script>displaySuccessMessage();</script>';
                                } else {
                                    echo "Error: " . $sql . "<br>";
                                }
                            } else {
                                echo "Error: " . $sql2 . "<br>";
                            }
                        }

                    ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS, Popper.js, and jQuery -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

    <?php include "footer.php";?>

</body>

</html>
