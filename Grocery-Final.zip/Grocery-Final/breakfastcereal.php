

<?php
include 'config.php';
session_start();
if (isset($_SESSION['username'])) {
    echo "Hello, ", $_SESSION['username'];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"></script>

    <script src="scripts/contactus.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">


    <title>Grocery: Breakfast and Cereal</title>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .top {
            background-color: #007bff;
            padding: 10px;
            color: white;
            text-align: center;
        }

        .top img {
            max-width: 100px;
            max-height: 100px;
            margin-right: 10px;
        }

        .navbar {
            background-color: #ffffff;
            border-bottom: 1px solid #dee2e6;
        }

        .navbar-brand {
            color: #007bff;
            font-size: 24px;
            font-weight: bold;
        }

        .navbar-nav .nav-link {
            color: #495057;
        }

        .row {
            margin: 20px 0;
        }

        .column {
            background-color: rgb(222, 221, 226);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .column2 {
            background-color: aliceblue;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        footer {
            background-color: #343a40;
            color: #ffffff;
            padding: 10px 0;
            text-align: center;
            position: relative;
            bottom: 0;
            width: 100%;
        }

        .search {
            margin-top: 15px;
            text-align: center;
        }

        .search input {
            width: 60%;
            margin-right: 10px;
        }

        .search button {
            width: 30%;
        }

        .btn {
            margin: 5px;
        }

        .rowCard {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
        }

        .columnCard {
            width: 100%;
            margin-bottom: 20px;
        }

        .card {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: 0.3s;
            border-radius: 8px;
        }

        .container {
            padding: 10px;
        }

        input[type="number"] {
            width: 50px;
            text-align: center;
            margin-right: 5px;
        }

        /* Filter */
.filterDiv {
    display: none; /* Hidden by default */
}

  .show {
    display: block;
  }
  
  .containerFilter {
    margin-top: 20px;
    overflow: hidden;
  }
    </style>
</head>

<body>
    <div class="top">
        <img src="images/groceries.jpeg">
        <h1>Grocery</h1>
    </div>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Grocery</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="freshproducts.php">Fresh Products</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="frozen.php">Frozen</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="pantry.php">Pantry</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="breakfastcereal.php">Breakfast & Cereal</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="baking.php">Baking</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="snacks.php">Snacks</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="candy.php">Candy</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="specialtyshops.php">Specialty Shops</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="deals.php">Deals</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="aboutus.php">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contactus.php">Contact Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="myaccount.php">My Account</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="cart.php">Shopping Cart</a>
                </li>            
            </ul>
        </div>
    </nav>

    <div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="column2">
                <h3 class="text-center">Breakfast and Cereal</h3>
                <form class="search">
                    <input type="text" placeholder="Search..." name="search">
                    <button type="submit">Search<i class="fa fa-search"></i></button>
                </form>

                <div id="myBtnContainer" style="text-align:center; padding-top:15px;">
                    <button class="btn active" onclick="filterSelection('all')"> Show all</button>
                    <button class="btn" onclick="filterSelection('cereal')"> Cereal</button>
                    <button class="btn" onclick="filterSelection('pancakes')"> Pancakes & Waffles</button>
                    <button class="btn" onclick="filterSelection('breads')"> Breakfast Breads</button>
                    <button class="btn" onclick="filterSelection('oatmeal')"> Oatmeal</button>
                    <button class="btn" onclick="filterSelection('rollbacks')"> Rollbacks</button>
                </div>
            </div>
        </div>
    </div>

    <div class="rowCard" id="productCards">
        <?php
        // Query to select data from the Inventory table
        $sql = "SELECT ItemNumber, Name, Category, Subcategory, UnitPrice, QuantityInInventory, ImageSrc FROM Inventory WHERE Category = 'Pantry'";
        $result = $conn->query($sql);

        // Check if there are rows in the result
        if ($result->num_rows > 0) {
            // Iterate through each row
            while ($row = $result->fetch_assoc()) {
                // Output HTML based on each row's data
                echo '<div class="col-md-3 mb-4 filterDiv show" data-category="' . strtolower($row['Subcategory']) . '">';
                echo '<div class="card product-card">';
                echo '<img src="' . $row['ImageSrc'] . '" alt="Avatar" class="card-img-top">';
                echo '<div class="card-body">';
                echo '<h5 class="card-title">' . $row['Name'] . '</h5>';
                echo '<p class="card-text"><strong>$' . number_format($row['UnitPrice'], 2) . '</strong></p>';
                echo '<input type="number" class="form-control" id="' . strtolower($row['Name']) . '-quantity" name="' . strtolower($row['Name']) . '-quantity" min="1" max="10" value="1">';
                echo '<button type="button" class="btn btn-primary" onclick="addToCart(\'' . $row['Name'] . '\', \'' . $row['QuantityInInventory'] . '\')">Add to Cart</button>';
                echo '</div>';
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo "No items found in the inventory.";
        }
        ?>
    </div>
</div>

    <?php include 'footer.php'; ?>

    <script src="scripts/breakfast.js"></script>
    <script src="scripts/filter.js"></script>
    <script src="scripts/inventoryItems.js"></script>
</body>

</html>
