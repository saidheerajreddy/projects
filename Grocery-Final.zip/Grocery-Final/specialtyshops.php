


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="scripts/contactus.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

    <title>Grocery: Specialty Shops</title>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .top {
            background-color: #007bff;
            padding: 10px;
            color: white;
            text-align: center;
        }

        .top img {
            max-width: 100px;
            max-height: 100px;
            margin-right: 10px;
        }

        .navbar {
            background-color: #ffffff;
            border-bottom: 1px solid #dee2e6;
        }

        .navbar-brand {
            color: #007bff;
            font-size: 24px;
            font-weight: bold;
        }

        .navbar-nav .nav-link {
            color: #495057;
        }

        .row {
            margin: 20px 0;
        }

        .column {
            background-color: #eee;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .column2 {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        footer {
            background-color: #343a40;
            color: #ffffff;
            padding: 10px 0;
            text-align: center;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

        .search {
            margin-top: 15px;
        }

        .specialOfferButton {
            background-color: #28a745;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        #questionContainer {
            display: none;
            text-align: center;
        }

        #resultContainer {
            display: none;
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="top">
        <img src="images/groceries.jpeg">
        <h1>Grocery</h1>
    </div>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Grocery</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="freshproducts.php">Fresh Products</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="frozen.php">Frozen</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="pantry.php">Pantry</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="breakfastcereal.php">Breakfast & Cereal</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="baking.php">Baking</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="snacks.php">Snacks</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="candy.php">Candy</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="specialtyshops.php">Specialty Shops</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="deals.php">Deals</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="aboutus.php">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contactus.php">Contact Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="myaccount.php">My Account</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="cart.php">Shopping Cart</a>
                </li>                        
            </ul>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="column2">
                    <h3 class="text-center">Specialty Shops</h3>
                    <div class="text-center">
                    <button class="specialOfferButton" id="specialOfferButton">Click to answer special offer questionnaire!</button>
                    </div>

                    <div id="questionContainer">
                        <h4>Question 1: Are you a student?</h4>
                        <p><br></p>
                        <label><input type="radio" name="student" value="yes"> Yes</label>
                        <label><input type="radio" name="student" value="no"> No</label>
                        <button id="nextButton">Next</button>
                        <button id="skipButton">Skip</button>
                    </div>

                    <div id="questionContainer">
                        <h4>Question 2: Are you a low income person?</h4>
                        <p><br></p>
                        <label><input type="radio" name="student" value="yes"> Yes</label>
                        <label><input type="radio" name="student" value="no"> No</label>
                        <button id="nextButton">Next</button>
                        <button id="skipButton">Skip</button>
                    </div>
                    <div id="questionContainer">
                        <h4>Question 3: Are you a member of Grocery?</h4>
                        <p><br></p>
                        <label><input type="radio" name="student" value="yes"> Yes</label>
                        <label><input type="radio" name="student" value="no"> No</label>
                        <button id="nextButton">Next</button>
                        <button id="skipButton">Skip</button>
                    </div>
                    <div id="resultContainer">
                        <h4><b><u>Special Offer Result</u></b></h4>
                        <p id="qualificationReason"></p>
                        <p id="offerDetails"></p>
                        <p id="timeSpent"></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

        <?php include 'footer.php'; ?>


    <script src="scripts/specialtyshops.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>

</html>
