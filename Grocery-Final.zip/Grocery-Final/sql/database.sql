-- Create Inventory table
CREATE TABLE Inventory (
    ItemNumber INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(255),
    Category VARCHAR(255),
    Subcategory VARCHAR(255),
    UnitPrice DECIMAL(10, 2),
    QuantityInInventory INT,
    ImageSrc VARCHAR(255)
);

-- Create Customers table
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY AUTO_INCREMENT,
    FirstName VARCHAR(255),
    LastName VARCHAR(255),
    Age INT,
    Email VARCHAR(255),
    PhoneNumber VARCHAR(20),
    Address VARCHAR(255),
    ZipCode VARCHAR(10)
);

-- Create Users table
CREATE TABLE Users (
    CustomerID INT PRIMARY KEY,
    UserName VARCHAR(255),
    Password VARCHAR(255),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)

);

-- Create Transactions table
CREATE TABLE Transactions (
    CustomerID INT,
    TransactionID INT PRIMARY KEY AUTO_INCREMENT,
    TransactionStatus VARCHAR(50),
    TransactionDate DATE,
    TotalPrice DECIMAL(10, 2),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

-- Create Carts table
CREATE TABLE Carts (
    CartID INT PRIMARY KEY AUTO_INCREMENT,
    CustomerID INT,
    TransactionID INT,
    ItemNumber INT,
    Quantity INT,
    CartStatus VARCHAR(50),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
    FOREIGN KEY (TransactionID) REFERENCES Transactions(TransactionID),
    FOREIGN KEY (ItemNumber) REFERENCES Inventory(ItemNumber)
);
