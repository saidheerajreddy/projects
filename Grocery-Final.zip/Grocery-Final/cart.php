<?php
include 'config.php';
session_start();
if (isset($_SESSION['username'])) {
    echo "Hello, ", $_SESSION['username'];
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="scripts/contactus.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>


    <title>Grocery: Cart</title>
    <style>
    body {
        background-color: #f8f9fa;
        margin: 0;
        padding: 0;
    }

    .top {
        background-color: #007bff;
        padding: 10px;
        color: white;
        text-align: center;
    }

    .top img {
        max-width: 100px;
        max-height: 100px;
        margin-right: 10px;
    }

    nav {
        background-color: #ffffff;
        border-bottom: 1px solid #dee2e6;
    }

    .navbar-brand {
        color: #007bff;
        font-size: 24px;
        font-weight: bold;
    }

    .navbar-nav .nav-link {
        color: #495057;
    }

    .container {
        margin-top: 20px;
    }

    .column2 {
        background-color: aliceblue;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .column2 table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .column2 table,
    .column2 th,
    .column2 td {
        border: 1px solid #dee2e6;
    }

    .column2 th,
    .column2 td {
        padding: 12px;
        text-align: left;
    }

    .column2 th {
        background-color: #007bff;
        color: white;
    }

    .logout {
        text-align: right;
        margin-bottom: 20px;
    }

    .logoutButton {
        background-color: #dc3545;
        color: white;
        border: none;
        padding: 5px 10px;
        border-radius: 4px;
        cursor: pointer;
    }

    h2,
    h3,
    h5 {
        margin-top: 20px;
    }

    form {
        margin-top: 20px;
    }

    label {
        margin-right: 10px;
    }

    input,
    select {
        margin-bottom: 10px;
        width: 100%;
        padding: 8px;
        box-sizing: border-box;
    }

    input[type="submit"] {
        background-color: #007bff;
        color: white;
        border: none;
        padding: 10px 15px;
        border-radius: 4px;
        cursor: pointer;
    }

    .filterDiv {
        display: none;
    }

    .show {
        display: block;
    }

    .containerFilter {
        margin-top: 20px;
        overflow: hidden;
    }

    footer {
            background-color: #343a40;
            color: #ffffff;
            padding: 10px 0;
            text-align: center;
            position: relative;
            bottom: 0;
            width: 100%;
        }
</style>


</head>

<body>
    <div class="top">
        <img src="images/groceries.jpeg" alt="Grocery Logo">
        <h1>Grocery</h1>
    </div>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Grocery</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <!-- Add your navigation links here -->
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="freshproducts.php">Fresh Products</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="frozen.php">Frozen</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="pantry.php">Pantry</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="breakfastcereal.php">Breakfast & Cereal</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="baking.php">Baking</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="snacks.php">Snacks</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="candy.php">Candy</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="specialtyshops.php">Specialty Shops</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="deals.php">Deals</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="aboutus.php">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contactus.php">Contact Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="myaccount.php">My Account</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="cart.php">Shopping Cart</a>
                </li>
            </ul>
        </div>
    </nav>
    
        <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="column2">
                <div>
                    <h3>Shopping Cart</h3>
                    <?php
                                
                        // Check if the user is not logged in
                        if (!isset($_SESSION['username'])) {
                            // Redirect to the myaccount.php page
                            echo '<h5>Not signed in? <a href="myaccount.php">Login Now!</a></h5>';
                            //exit(); // Stop further execution of the script
                        }
                    ?>
                    
                    
                    <table id="cartTable" style="width:100%">
                        <thead>
                            <tr>
                                <th style="text-align:left">Item</th>
                                <th>Quantity</th>
                                <th>Price</th>
                            </tr> 
                            

                        </thead>
                        <tbody>
            
                        </tbody>
                    </table>
                    <p></p>
                    <?php include 'displayCart.php'; ?>
                    <p></p>
                    <button type="button" class="clearButton">Clear Cart</button>
                    <button type="button" class="checkoutButton">Checkout</button>

                </div>
            </div>
        </div>
    </div>
</div>


    <script src="scripts/inventoryItems.js"></script>
    <script src="scripts/cart.js"></script>

    <?php
        
        // Function to update XML file and return success status
        function updateXML($productName, $quantity, $xmlFilePath) {
            // Load XML file
            $xml = simplexml_load_file($xmlFilePath);

            // Find the product by name
            foreach ($xml->product as $product) {
                if ((string)$product->name === $productName) {
                    // Update the quantity
                    $product->quantity = $product->quantity - $quantity;

                    $xml->asXML($xmlFilePath);

                    return true;
                }
            }

            return false;
        }

        // Function to update JSON file and return success status
        function updateJSON($productName, $quantity, $jsonFilePath) {
            // Load JSON file
            $jsonFile = file_get_contents($jsonFilePath);
            $jsonArray = json_decode($jsonFile, true);

            // Find the product by name
            foreach ($jsonArray as &$product) {
                if ($product['name'] === $productName) {
                    // Update the quantity
                    $product['quantity'] = $product['quantity'] - $quantity;

                    file_put_contents($jsonFilePath, json_encode($jsonArray, JSON_PRETTY_PRINT));

                    return true;
                }
            }

            return false;
        }

        // Check if 'cartData' is set in the POST request
        if (isset($_POST['cartData'])) {
            $cartData = json_decode($_POST['cartData'], true);

            $xmlFilePaths = ['xml/candy.xml', 'xml/freshproduce.xml', 'xml/frozen.xml', 'xml/snacks.xml']; 
            $jsonFilePaths = ['json/baking.json', 'json/breakfast.json', 'json/pantry.json'];

            // Update quantities in XML files
            foreach ($xmlFilePaths as $xmlFilePath) {
                foreach ($cartData as $cartItem) {
                    $productName = $cartItem['name'];
                    $quantity = $cartItem['quantity'];

                    // Check if the file was updated
                    if (updateXML($productName, $quantity, $xmlFilePath)) {
                        echo "XML file $xmlFilePath was updated successfully.\n";
                    } else {
                        echo "Failed to update XML file $xmlFilePath.\n";
                    }
                }
            }

            // Update quantities in JSON files
            foreach ($jsonFilePaths as $jsonFilePath) {
                foreach ($cartData as $cartItem) {
                    $productName = $cartItem['name'];
                    $quantity = $cartItem['quantity'];

                    // Check if the file was updated
                    if (updateJSON($productName, $quantity, $jsonFilePath)) {
                        echo "JSON file $jsonFilePath was updated successfully.\n";
                    } else {
                        echo "Failed to update JSON file $jsonFilePath.\n";
                    }
                }
            } 
        } else {
       //     echo "Error: 'cartData' not present in the POST request.";
        }
    ?>

<?php include "footer.php";?>
    

</body>

</html>