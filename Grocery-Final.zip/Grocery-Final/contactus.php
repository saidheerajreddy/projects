<?php
include 'config.php';
session_start();
if (isset($_SESSION['username'])) {
    echo "Hello, ", $_SESSION['username'];
}
?>

<!DOCTYPE html>
<html>

<head>
    <script src="scripts/contactus.js"></script>
    <title>Grocery: Contact Us</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">



    <style type="text/css">
         body {
            background-color: #f8f9fa;
        }

        .top {
            background-color: #007bff;
            padding: 10px;
            color: white;
            text-align: center;
        }

        .top img {
            max-width: 100px;
            max-height: 100px;
            margin-right: 10px;
        }

        .navbar {
            background-color: #ffffff;
            border-bottom: 1px solid #dee2e6;
        }

        .navbar-brand {
            color: #007bff;
            font-size: 24px;
            font-weight: bold;
        }

        .navbar-nav .nav-link {
            color: #495057;
        }

        .row {
            margin: 20px 0;
        }

        .column {
            background-color: #ddd;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .column2 {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        footer {
            background-color: #343a40;
            color: #ffffff;
            padding: 10px 0;
            text-align: center;
            position: relative;
            bottom: 0;
            width: 100%;
        }

        .rowCard {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
        }

        .columnCard {
            width: 50%;
            padding: 1rem;
            margin-bottom: 20px;
        }

        .card {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: 0.3s;
            border-radius: 8px;
        }

        .container {
        }

        input[type="number"] {
            width: 50px;
            text-align: center;
            margin-right: 5px;
        }

        .center {
            text-align: center;
        }
    </style>
</head>

<body>

     <div class="top">
        <img src="images/groceries.jpeg">
        <h1>Grocery</h1>
    </div>


    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Grocery</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="freshproducts.php">Fresh Products</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="frozen.php">Frozen</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="pantry.php">Pantry</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="breakfastcereal.php">Breakfast & Cereal</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="baking.php">Baking</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="snacks.php">Snacks</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="candy.php">Candy</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="specialtyshops.php">Specialty Shops</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="deals.php">Deals</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="aboutus.php">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contactus.php">Contact Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="myaccount.php">My Account</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="cart.php">Shopping Cart</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="column2">
                    <h3 class="text-center">Contact Us</h3>
                    <form name="commentForm" class="login">
                        <div class="form-group">
                            <label for="first">First Name:</label>
                            <input type="text" class="form-control" id="first" name="first" required>
                        </div>
                        <div class="form-group">
                            <label for="last">Last Name:</label>
                            <input type="text" class="form-control" id="last" name="last" required>
                        </div>
                        <div class="form-group">
                            <label for="number">Phone Number:</label>
                            <input type="text" class="form-control" id="number" name="number" placeholder="(012) 345-6789" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email Address:</label>
                            <input type="text" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label>Gender:</label>
                            <div class="form-check">
                                <input type="radio" class="form-check-input" name="gender" value="male" id="male">
                                <label class="form-check-label" for="male">Male</label>
                            </div>
                            <div class="form-check">
                                <input type="radio" class="form-check-input" name="gender" value="female" id="female">
                                <label class="form-check-label" for="female">Female</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="comment">Comment:</label>
                            <input type="text" class="form-control" id="comment" name="comment" required>
                        </div>
                        <button type="button" class="btn btn-primary" id="commentButton" onclick="validateForm()">Submit</button>
                    </form>
                    <div style="color: red;">
                        <h6 id="firstMessage"></h6>
                        <h6 id="lastMessage"></h6>
                        <h6 id="diffMessage"></h6>
                        <h6 id="phoneMessage"></h6>
                        <h6 id="emailMessage"></h6>
                        <h6 id="genderMessage"></h6>
                        <h6 id="commentMessage"></h6>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include "footer.php";?>

</body>

</html>


