<?php
include 'config.php';
session_start();
if (isset($_SESSION['username'])) {
    echo "Hello, ", $_SESSION['username'];
}
?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <script src="scripts/contactus.js"></script>
    <script src="scripts/cart.js"></script>


    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

    <title>Grocery: MyAccount</title>
    <style>
    body {
        background-color: #f8f9fa;
        margin: 0;
        padding: 0;
    }

    .top {
        background-color: #007bff;
        padding: 10px;
        color: white;
        text-align: center;
    }

    .top img {
        max-width: 100px;
        max-height: 100px;
        margin-right: 10px;
    }

    nav {
        background-color: #ffffff;
        border-bottom: 1px solid #dee2e6;
    }

    .navbar-brand {
        color: #007bff;
        font-size: 24px;
        font-weight: bold;
    }

    .navbar-nav .nav-link {
        color: #495057;
    }

    .container {
        margin-top: 20px;
    }

    .column2 {
        background-color: aliceblue;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .column2 table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .column2 table,
    .column2 th,
    .column2 td {
        border: 1px solid #dee2e6;
    }

    .column2 th,
    .column2 td {
        padding: 12px;
        text-align: left;
    }

    .column2 th {
        background-color: #007bff;
        color: white;
    }

    .logout {
        text-align: right;
        margin-bottom: 20px;
    }

    .logoutButton {
        background-color: #dc3545;
        color: white;
        border: none;
        padding: 5px 10px;
        border-radius: 4px;
        cursor: pointer;
    }

    h2,
    h3,
    h5 {
        margin-top: 20px;
    }

    form {
        margin-top: 20px;
    }

    label {
        margin-right: 10px;
    }

    input,
    select {
        margin-bottom: 10px;
        width: 100%;
        padding: 8px;
        box-sizing: border-box;
    }

    input[type="submit"] {
        background-color: #007bff;
        color: white;
        border: none;
        padding: 10px 15px;
        border-radius: 4px;
        cursor: pointer;
    }

    .filterDiv {
        display: none;
    }

    .show {
        display: block;
    }

    .containerFilter {
        margin-top: 20px;
        overflow: hidden;
    }

    footer {
            background-color: #343a40;
            color: #ffffff;
            padding: 10px 0;
            text-align: center;
            position: relative;
            bottom: 0;
            width: 100%;
        }
</style>

</head>

<body>
    <div class="top">
        <img src="images/groceries.jpeg" alt="Grocery Logo">
        <h1>Grocery</h1>
    </div>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Grocery</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <!-- Add your navigation links here -->
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="freshproducts.php">Fresh Products</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="frozen.php">Frozen</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="pantry.php">Pantry</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="breakfastcereal.php">Breakfast & Cereal</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="baking.php">Baking</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="snacks.php">Snacks</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="candy.php">Candy</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="specialtyshops.php">Specialty Shops</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="deals.php">Deals</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="aboutus.php">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contactus.php">Contact Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="myaccount.php">My Account</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="cart.php">Shopping Cart</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="column2">
                    <!-- Your PHP code goes here -->
                    <?php

                // Check if the user is logged in
                if (isset($_SESSION['username'])) {
                    // User is logged in, show logout button
                    echo '<form class="logout" method="post" action="logout.php">';
                    echo '<input type="submit" class="logoutButton" value="Logout">';
                    echo '</form>';

                    if ($_SESSION['username'] == "admin") {
                        echo '<form action="readInventory.php" method="post" enctype="multipart/form-data" style="text-align:center;">';
                        echo '    <label for="file">Select File:</label>';
                        echo '    <input type="file" name="file" id="file" accept=".xml, .json" required>';
                        echo '    <br>';
                        echo '    <label for="category">Select Category:</label>';
                        echo '    <select name="category" id="category" required>';
                        echo '        <option value="fresh">Fresh Products</option>';
                        echo '        <option value="frozen">Frozen Products</option>';
                        echo '        <option value="candy">Candy</option>';
                        echo '        <option value="snacks">Snacks</option>';
                        echo '        <option value="baking">Baking Products</option>';
                        echo '        <option value="breakfast">Breakfast Products</option>';
                        echo '        <option value="pantry">Pantry Products</option>';
                        echo '    </select>';
                        echo '    <br>';
                        echo '    <input type="submit" value="Upload" name="submit">';
                        echo '</form>';

                        $sql = "SELECT * FROM Inventory";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            // Display the inventory table content in a table or format of your choice
                            echo "<h2>All Inventory:</h2>";
                            echo "<table border='1'>";
                            echo "<tr><th>Item Number</th><th>Name</th><th>Category</th><th>Subcategory</th><th>Unit Price</th><th>Quantity in Inventory</th><th>Image Source</th></tr>";
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . $row["ItemNumber"] . "</td>";
                                echo "<td>" . $row["Name"] . "</td>";
                                echo "<td>" . $row["Category"] . "</td>";
                                echo "<td>" . $row["Subcategory"] . "</td>";
                                echo "<td>" . $row["UnitPrice"] . "</td>";
                                echo "<td>" . $row["QuantityInInventory"] . "</td>";
                                echo "<td>" . $row["ImageSrc"] . "</td>";
                                echo "</tr>";
                            }
                            echo "</table>";
                        } else {
                            echo "No records found in the inventory table.";
                        }

                        // SQL query to select items with quantity less than 3
                        $sql = "SELECT * FROM Inventory WHERE QuantityInInventory < 3";

                        // Execute the query
                        $result = $conn->query($sql);

                        // Check if there are rows in the result set
                        if ($result->num_rows > 0) {
                            echo "<h2>Items Low in Inventory:</h2>";
                            echo "<table border='1'>";
                            echo "<tr><th>Item Number</th><th>Name</th><th>Category</th><th>Subcategory</th><th>Unit Price</th><th>Quantity in Inventory</th><th>Image Source</th></tr>";

                            // Output data of each row
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . $row["ItemNumber"] . "</td>";
                                echo "<td>" . $row["Name"] . "</td>";
                                echo "<td>" . $row["Category"] . "</td>";
                                echo "<td>" . $row["Subcategory"] . "</td>";
                                echo "<td>" . $row["UnitPrice"] . "</td>";
                                echo "<td>" . $row["QuantityInInventory"] . "</td>";
                                echo "<td>" . $row["ImageSrc"] . "</td>";
                                echo "</tr>";
                            }

                            echo "</table>";
                            echo '<h1></h1>';

                        } else {
                            echo "<h2>Items Low in Inventory:</h2>";

                            echo '<p>No items are low in inventory.</p>';
                        }

                        // Form to input specific date
                        echo '<form method="post" action="' . $_SERVER['PHP_SELF'] . '">';
                        echo '    <label for="selectedDate">Enter Specific Date:</label>';
                        echo '    <input type="date" id="selectedDate" name="selectedDate" required>';
                        echo '    <input type="submit" value="Submit">';
                        echo '</form>';

                        if ($_SERVER["REQUEST_METHOD"] == "POST") {
                            // Retrieve user input from the form
                            $selectedDate = $_POST['selectedDate'];
                        
                            // SQL query to retrieve customers with more than 2 transactions on the selected date
                            $sql = "SELECT
                                        c.CustomerID,
                                        c.FirstName,
                                        c.LastName,
                                        COUNT(t.TransactionID) AS TransactionCount
                                    FROM
                                        Customers c
                                    JOIN
                                        Users u ON c.CustomerID = u.CustomerID
                                    JOIN
                                        Transactions t ON u.CustomerID = t.CustomerID
                                    WHERE
                                        DATE(t.TransactionDate) = '$selectedDate'
                                    GROUP BY
                                        c.CustomerID
                                    HAVING
                                        TransactionCount > 2";

                        
                            $result = $conn->query($sql);

                            if (isset($result) && $result->num_rows > 0) {
                                echo '<h2>Customers with More Than 2 Transactions on ' . $selectedDate . '</h2>';
                                echo '<table>';
                                echo '<tr>';
                                echo '<th>CustomerID</th>';
                                echo '<th>Name</th>';
                                echo '<th>Transaction Count</th>';
                                echo '</tr>';
                            
                                while ($row = $result->fetch_assoc()) {
                                    echo '<tr>';
                                    echo '<td>' . $row['CustomerID'] . '</td>';
                                    echo '<td>' . $row['FirstName'] . ' ' . $row['LastName'] . '</td>';
                                    echo '<td>' . $row['TransactionCount'] . '</td>';
                                    echo '</tr>';
                                }
                            
                                echo '</table>';
                            } elseif (isset($result)) {
                                echo '<p>No results found for the selected date.</p>';
                            }
                        }

                     //   echo '<h2>Admin Customer List</h2>';
                        // Initialize variables for user input
                        $itemNumber = "";
                        $newUnitPrice = "";
                        $newQuantity = "";


                        echo '<h2>Enter Zipcode and Month</h2>';
                        echo '<form action="' . $_SERVER['PHP_SELF'] . '" method="post">';
                        echo '    <label for="zipCode">Enter Zip Code:</label>';
                        echo '    <input type="text" id="zipCode" name="zipCode" required>';
                        echo '    <label for="month">Enter Month (1-12):</label>';
                        echo '    <input type="number" id="month" name="month" min="1" max="12" required>';
                        echo '    <input type="submit" value="Submit">';
                        echo '</form>';

                        // Check if the form is submitted
                        if ($_SERVER["REQUEST_METHOD"] == "POST") {

                            if (isset($_POST["zipCode"], $_POST["month"])) {

                                // Retrieve user inputs from the form
                                $specifiedZipCode = $_POST['zipCode'];
                                $specifiedMonth = $_POST['month'];

                                // SQL query
                                $sql = "SELECT
                                c.CustomerID,
                                c.FirstName,
                                c.LastName,
                                c.Address,
                                c.Zipcode
                            FROM
                                Customers c
                            JOIN
                                Transactions t ON c.CustomerID = t.CustomerID
                            JOIN
                                Carts ca ON c.CustomerID = ca.CustomerID
                            WHERE
                                c.Zipcode = '$specifiedZipCode'
                                AND MONTH(t.TransactionDate) = $specifiedMonth
                            GROUP BY
                                c.CustomerID
                            HAVING
                                COUNT(t.TransactionID) > 2";

                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                    echo '<table>';
                                    echo '<tr>';
                                    echo '<th>CustomerID</th>';
                                    echo '<th>Name</th>';
                                    echo '<th>Address</th>';
                                    echo '<th>Zipcode</th>';
                                    echo '</tr>';

                                    while ($row = $result->fetch_assoc()) {
                                        echo '<tr>';
                                        echo '<td>' . $row['CustomerID'] . '</td>';
                                        echo '<td>' . $row['FirstName'] . ' ' . $row['LastName'] . '</td>';
                                        echo '<td>' . $row['Address'] . '</td>';
                                        echo '<td>' . $row['Zipcode'] . '</td>';
                                        echo '</tr>';
                                    }

                                    echo '</table>';
                                } else {
                                    echo 'No results found.';
                                }
                            }
                        }

                        echo '<h2>Update Inventory Form</h2>';
                        echo '<form action="' . $_SERVER['PHP_SELF'] . '" method="post">';
                        echo '    <label for="itemNumber">Enter Item Number:</label>';
                        echo '    <input type="text" id="itemNumber" name="itemNumber" required>';
                        echo '    <label for="newUnitPrice">Enter New Unit Price:</label>';
                        echo '    <input type="number" id="newUnitPrice" name="newUnitPrice" step="0.01" required>';
                        echo '    <label for="newQuantity">Enter New Quantity:</label>';
                        echo '    <input type="number" id="newQuantity" name="newQuantity" required>';
                        echo '    <input type="submit" value="Submit">';
                        echo '</form>';

                        // Check if the form is submitted
                        if ($_SERVER["REQUEST_METHOD"] == "POST") {
                            if (isset($_POST["itemNumber"], $_POST["newUnitPrice"], $_POST["newQuantity"])) {
                                // Retrieve user inputs from the form
                                $itemNumber = $_POST["itemNumber"];
                                $newUnitPrice = $_POST["newUnitPrice"];
                                $newQuantity = $_POST["newQuantity"];

                                // SQL query to update the values in the Inventory table
                                $sql = "UPDATE Inventory
                                SET UnitPrice = '$newUnitPrice', QuantityInInventory = '$newQuantity'
                                WHERE ItemNumber = '$itemNumber'";

                                if ($conn->query($sql) === TRUE) {
                                    echo "Record updated successfully";
                                } else {
                                    echo "Error updating record: ";
                                }
                            }
                        }
                        // more that 20 yrs
                
                        $sql = "SELECT
                            c.CustomerID,
                            c.FirstName,
                            c.LastName,
                            c.Age,
                            COUNT(t.TransactionID) AS TransactionCount
                        FROM
                            Customers c
                        LEFT JOIN
                            Transactions t ON c.CustomerID = t.CustomerID
                        WHERE
                            c.Age > 20
                        GROUP BY
                            c.CustomerID
                        HAVING
                            TransactionCount > 3";

                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            echo '<h2>Customers Older Than 20 with More Than 3 Transactions</h2>';
                            echo '<table>';
                            echo '<tr>';
                            echo '<th>CustomerID</th>';
                            echo '<th>Name</th>';
                            echo '<th>Age</th>';
                            echo '<th>Transaction Count</th>';
                            echo '</tr>';

                            while ($row = $result->fetch_assoc()) {
                                echo '<tr>';
                                echo '<td>' . $row['CustomerID'] . '</td>';
                                echo '<td>' . $row['FirstName'] . ' ' . $row['LastName'] . '</td>';
                                echo '<td>' . $row['Age'] . '</td>';
                                echo '<td>' . $row['TransactionCount'] . '</td>';
                                echo '</tr>';
                            }

                            echo '</table>';
                        } else {
                            echo 'No customers found.';
                        }

                
                    } else {
                        include 'displayUserTable.php';
                        echo '<p></p>';
                        echo '<form method="post" action="displayUserTable.php">';
                        echo '    <label for="filterType">Select Filter:</label>';
                        echo '    <select name="filterType" id="filterType" onchange="showInput()">';
                        echo '        <option value="month">Transactions in a Specific Month</option>';
                        echo '        <option value="last3months">Last 3 Months</option>';
                        echo '        <option value="year">Transactions in a Specific Year</option>';
                        echo '    </select>';

                        echo '    <div id="monthInput" style="display: none;">';
                        echo '        <label for="selectedMonth">Select Month:</label>';
                        echo '        <input type="number" name="selectedMonth" min="1" max="12">';
                        echo '    </div>';

                        echo '    <div id="yearInput" style="display: none;">';
                        echo '        <label for="selectedYear">Select Year:</label>';
                        echo '        <input type="number" name="selectedYear" min="2000" max="' . date('Y') . '">';
                        echo '    </div>';

                        echo '    <input type="submit" name="generateButton" value="Generate">';
                        echo '</form>';
                    }

                } else {
                    // User is not logged in, show login form
                    echo '<h3>My Account</h3>';
                    echo '<form class="login" method="post" action="login.php">';
                    echo '<div class="containerLogin"> ';
                    echo '<label>Username: </label>';
                    echo '<input type="text" placeholder="Enter Username" name="username" required>';
                    echo '<label>Password: </label>';
                    echo '<input type="password" placeholder="Enter Password" name="password" required>';
                    echo '<input type="submit" class="loginButton" value="Login">';
                    echo '<h5 style="text-align:left">Password requirements:</h5>';
                    echo '<ul style="font-size:10pt">';
                    echo '<li>At least 8 characters</li>';
                    echo '<li>Lowercase character</li>';
                    echo '<li>Number</li>';
                    echo '</ul>';
                    echo '</div>';
                    echo '</form>';
                    echo '<h5>Don\'t have an account? <a href="register.php">Register Now</a></h5>';
                }
                ?>

                

                <script>
                    // JavaScript function to show/hide input based on filter type
                    function showInput() {
                        var filterType = document.getElementById("filterType").value;
                        var monthInput = document.getElementById("monthInput");
                        var yearInput = document.getElementById("yearInput");

                        // Hide all inputs initially
                        monthInput.style.display = "none";
                        yearInput.style.display = "none";

                        // Show input based on filter type
                        if (filterType === "month") {
                            monthInput.style.display = "block";
                        } else if (filterType === "year") {
                            yearInput.style.display = "block";
                        }
                    }
                </script>


                <script type="text/javascript">
                    
                    $(document).ready(function () {
                        // Retrieve cart data from session storage
                        const cartData = JSON.parse(sessionStorage.getItem('cartData'));
                        
                        $('.clearButton').on('click', function () {
                            const cartData = JSON.parse(sessionStorage.getItem('cartData')) || [];

                            if (cartData.length === 0) {
                                alert("Cart is already empty.");
                                return;
                            }
                            sessionStorage.removeItem('cartData');

                            // Retrieve inventoryList data from session storage
                            const inventoryList = JSON.parse(sessionStorage.getItem('inventoryList'));

                            if (inventoryList) {
                                // Add the values back to inventoryList
                                $.each(cartData, function (index, item) {
                                    const existingItem = inventoryList.find(function (inventoryItem) {
                                        // console.log(inventoryItem.name);
                                        // console.log(item.name);
                                        return inventoryItem.name === item.name.toLowerCase();
                                    });

                                    if (existingItem) {
                                        existingItem.quantity += item.quantity;
                                        console.log(existingItem.quantity);
                                    }
                                });

                                // Update the inventoryList data in session storage
                                sessionStorage.setItem('inventoryList', JSON.stringify(inventoryList));
                            }

                            $('#cartTable tbody').empty();

                            // add items in cart data back to inventory db
                            addBackInventory();
                            // change transaction status to cancelled
                            cancelTransaction();
                            // change cart status to cancelled
                            cancelCart();

                            location.reload();
                        });




                        });





                        // Function to cancel transaction
                        function cancelTransaction() {
                            // Create an XMLHttpRequest object
                            const xhr = new XMLHttpRequest();

                            // Configure it to send a POST request to your PHP script
                            xhr.open('POST', 'cancelTransaction.php', true);
                            xhr.setRequestHeader('Content-Type', 'application/json');

                            // Set up a callback function to handle the response from the server
                            xhr.onreadystatechange = function () {
                                if (xhr.readyState === XMLHttpRequest.DONE) {
                                    if (xhr.status === 200) {
                                        // Successful response from the server
                                        console.log(xhr.responseText);
                                    } else {
                                        // Handle errors
                                        console.error('Error cancelling transaction status:', xhr.responseText);
                                    }
                                }
                            };

                            // Send the request without any request data
                            xhr.send();
                        }

                        // Function to cancel transaction
                        function cancelCart() {
                            // Create an XMLHttpRequest object
                            const xhr = new XMLHttpRequest();

                            // Configure it to send a POST request to your PHP script
                            xhr.open('POST', 'cancelCartStatus.php', true);
                            xhr.setRequestHeader('Content-Type', 'application/json');

                            // Set up a callback function to handle the response from the server
                            xhr.onreadystatechange = function () {
                                if (xhr.readyState === XMLHttpRequest.DONE) {
                                    if (xhr.status === 200) {
                                        // Successful response from the server
                                        console.log(xhr.responseText);
                                    } else {
                                        // Handle errors
                                        console.error('Error cancelling cart status:', xhr.responseText);
                                    }
                                }
                            };

                            // Send the request without any request data
                            xhr.send();
                        }


                        function addBackInventory() {
                            // Create an XMLHttpRequest object
                            const xhr = new XMLHttpRequest();

                            // Configure it to send a POST request to your PHP script
                            xhr.open('POST', 'cancelInventory.php', true);
                            xhr.setRequestHeader('Content-Type', 'application/json');

                            // Set up a callback function to handle the response from the server
                            xhr.onreadystatechange = function () {
                                if (xhr.readyState === XMLHttpRequest.DONE) {
                                    if (xhr.status === 200) {
                                        // Successful response from the server
                                        console.log(xhr.responseText);
                                    } else {
                                        // Handle errors
                                        console.error('Error adding back inventory:', xhr.responseText);
                                    }
                                }
                            };

                            // Send the request without any request data
                            xhr.send();
                        }
                </script>







                </div>
            </div>
        </div>
    </div>

    <?php include "footer.php"; ?>

</body>


</html>
